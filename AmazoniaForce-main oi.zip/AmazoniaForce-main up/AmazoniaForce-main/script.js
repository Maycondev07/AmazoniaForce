/* ==========================================================================
   AMAZONIA FORCE - SCRIPT GLOBAL DO SITE
   ========================================================================== */

function toggleCart() {
    const miniCart = document.querySelector('.mini-cart');
    if (miniCart) miniCart.classList.toggle('active');
}

function closeLogin() {
    const modal = document.getElementById('loginModal');
    if (modal) modal.classList.remove('active');
}

function openLogin() {
    const session = localStorage.getItem('supabase.auth.token') || localStorage.getItem('user');

    if (session) {
        window.location.href = 'Routes/minha-conta.html';
    } else {
        const modal = document.getElementById('loginModal');
        if (modal) {
            modal.classList.add('active');
        } else {
            window.location.href = 'Routes/login.html';
        }
    }
}

document.addEventListener('DOMContentLoaded', () => {

    /* ---------------- LOADER ---------------- */
    const loader = document.querySelector('.loader');
    if (loader) {
        setTimeout(() => loader.classList.add('hide'), 400);
    }

    /* ---------------- HEADER SCROLL + BACK TO TOP ---------------- */
    const header = document.getElementById('header');
    const backToTop = document.getElementById('backToTop');

    window.addEventListener('scroll', () => {
        const scrolled = window.scrollY > 50;
        if (header) header.classList.toggle('scrolled', scrolled);
        if (backToTop) backToTop.classList.toggle('show', scrolled);
    });

    if (backToTop) {
        backToTop.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    /* ---------------- MENU MOBILE ---------------- */
    const menuToggle = document.querySelector('.menu-toggle');
    const navbarList = document.querySelector('.navbar > .container > ul');
    if (menuToggle && navbarList) {
        menuToggle.addEventListener('click', () => {
            navbarList.classList.toggle('mobile-open');
        });
    }

    /* ---------------- HERO SLIDER ---------------- */
    const slides = document.querySelectorAll('.hero-slider .slide');
    const dots = document.querySelectorAll('.hero-dot');
    let currentSlide = 0;
    let sliderInterval;

    function goToSlide(index) {
        if (!slides.length) return;
        slides[currentSlide].classList.remove('active');
        if (dots[currentSlide]) dots[currentSlide].classList.remove('active');
        currentSlide = (index + slides.length) % slides.length;
        slides[currentSlide].classList.add('active');
        if (dots[currentSlide]) dots[currentSlide].classList.add('active');
    }

    function startAutoSlide() {
        clearInterval(sliderInterval);
        if (slides.length > 1) {
            sliderInterval = setInterval(() => goToSlide(currentSlide + 1), 5000);
        }
    }

    if (slides.length) {
        const nextBtnHero = document.querySelector('.slider-next');
        const prevBtnHero = document.querySelector('.slider-prev');
        if (nextBtnHero) nextBtnHero.addEventListener('click', () => { goToSlide(currentSlide + 1); startAutoSlide(); });
        if (prevBtnHero) prevBtnHero.addEventListener('click', () => { goToSlide(currentSlide - 1); startAutoSlide(); });
        dots.forEach((dot, i) => dot.addEventListener('click', () => { goToSlide(i); startAutoSlide(); }));
        startAutoSlide();
    }

    /* ---------------- CARROSSEL PRODUCT COVERFLOW (RECALCULO DIRETO) ---------------- */
    const productTrack = document.getElementById('productsGrid');
    const prevBtnProduct = document.getElementById('singlePrev');
    const nextBtnProduct = document.getElementById('singleNext');

    if (productTrack) {
        let currentIndex = 0;
        let autoInterval = null;

        let startX = 0;
        let currentX = 0;
        let isTouching = false;

        function updateCarousel() {
            const cards = productTrack.querySelectorAll('.product-card');
            if (cards.length === 0) return;

            // Garantia de rotação infinita
            if (currentIndex < 0) {
                currentIndex = cards.length - 1;
            } else if (currentIndex >= cards.length) {
                currentIndex = 0;
            }

            const viewport = productTrack.parentElement;
            const targetCard = cards[currentIndex];

            // Posição do centro da tela em relação ao contêiner
            const viewportCenter = viewport.offsetWidth / 2;
            
            // Posição do centro do card desejado em relação à fita
            const cardCenter = targetCard.offsetLeft + (targetCard.offsetWidth / 2);

            // Quanto a fita deve deslizar no eixo X
            const translateOffset = viewportCenter - cardCenter;

            // Aplica a transição via propriedade inline direta
            productTrack.style.setProperty('transform', `translateX(${translateOffset}px)`, 'important');

            // Atualiza destaque visual dos cards
            cards.forEach((card, idx) => {
                if (idx === currentIndex) {
                    card.classList.add('active-card');
                } else {
                    card.classList.remove('active-card');
                }
            });
        }

        function next() {
            currentIndex++;
            updateCarousel();
        }

        function prev() {
            currentIndex--;
            updateCarousel();
        }

        function startAuto() {
            stopAuto();
            autoInterval = setInterval(next, 5000);
        }

        function stopAuto() {
            if (autoInterval) clearInterval(autoInterval);
        }

        /* --- BOTÕES LATERAIS --- */
        if (prevBtnProduct) {
            prevBtnProduct.addEventListener('click', (e) => {
                e.preventDefault();
                prev();
                startAuto();
            });
        }

        if (nextBtnProduct) {
            nextBtnProduct.addEventListener('click', (e) => {
                e.preventDefault();
                next();
                startAuto();
            });
        }

        /* --- GESTOS TOUCH (CELULAR/APP) --- */
        productTrack.addEventListener('touchstart', (e) => {
            stopAuto();
            isTouching = true;
            startX = e.touches[0].clientX;
            currentX = startX;
        }, { passive: true });

        productTrack.addEventListener('touchmove', (e) => {
            if (!isTouching) return;
            currentX = e.touches[0].clientX;
        }, { passive: true });

        productTrack.addEventListener('touchend', () => {
            if (!isTouching) return;
            isTouching = false;
            const diffX = currentX - startX;

            if (diffX > 40) {
                prev(); // Deslizou para a direita -> Volta
            } else if (diffX < -40) {
                next(); // Deslizou para a esquerda -> Avança
            }
            startAuto();
        }, { passive: true });

        /* --- DRAG MOUSE (PC) --- */
        productTrack.addEventListener('mousedown', (e) => {
            stopAuto();
            isTouching = true;
            startX = e.clientX;
            currentX = startX;
        });

        window.addEventListener('mousemove', (e) => {
            if (!isTouching) return;
            currentX = e.clientX;
        });

        window.addEventListener('mouseup', () => {
            if (!isTouching) return;
            isTouching = false;
            const diffX = currentX - startX;

            if (diffX > 40) {
                prev();
            } else if (diffX < -40) {
                next();
            }
            startAuto();
        });

        window.addEventListener('resize', updateCarousel);

        // Observa adição de dados assíncronos (Supabase)
        const observer = new MutationObserver(() => {
            if (productTrack.children.length > 0) {
                setTimeout(() => {
                    updateCarousel();
                    startAuto();
                }, 100);
                observer.disconnect();
            }
        });

        observer.observe(productTrack, { childList: true });
    }

    /* ---------------- BUSCA EM TEMPO REAL ---------------- */
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            const term = e.target.value.toLowerCase();
            document.querySelectorAll('.product-card').forEach(card => {
                const title = card.querySelector('h3') ? card.querySelector('h3').textContent.toLowerCase() : '';
                card.style.display = title.includes(term) ? '' : 'none';
            });
        });
    }

    /* ---------------- NEWSLETTER ---------------- */
    const newsletterForm = document.querySelector('.newsletter-form');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', (e) => {
            e.preventDefault();
            showToast('Inscrição realizada com sucesso!');
            newsletterForm.reset();
        });
    }

    /* ---------------- TOAST ---------------- */
    function showToast(msg) {
        const toast = document.getElementById('toast');
        if (!toast) return;
        toast.textContent = msg;
        toast.classList.add('show');
        setTimeout(() => toast.classList.remove('show'), 3000);
    }
});